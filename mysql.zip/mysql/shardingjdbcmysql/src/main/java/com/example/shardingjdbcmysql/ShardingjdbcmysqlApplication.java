package com.example.shardingjdbcmysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShardingjdbcmysqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShardingjdbcmysqlApplication.class, args);
    }

}
