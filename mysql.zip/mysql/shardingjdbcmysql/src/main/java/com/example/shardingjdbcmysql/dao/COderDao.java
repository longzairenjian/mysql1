package com.example.shardingjdbcmysql.dao;
import com.example.shardingjdbcmysql.entity.COrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface COderDao extends JpaRepository<COrder, Long> {
}
